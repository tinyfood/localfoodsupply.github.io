app.controller('Area3Controller', function () {
    console.log('Area3Controller');
    this.name = 'Area 3';
});