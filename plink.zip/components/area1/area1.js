app.controller('Area1Controller', function () {
    console.log('Area1Controller');
    this.name = 'Area 1';
    this.content = 'the places we will go! /n/n/r Its interesting to think about how things work in Australia vs. here, but from the first video I watched:     I was thinking that they created this network because the \'food desert\' effect was strongly limiting people\'s access to quality food.  - So they formed a really amazing network, complete with local organizing areas, and templates for new hubs. This allowed for new food distribution businesses to succeed.  This provided more confidence for the local farmer to plan for the needs of her expanded market, ... a healthy local economy had developed around the new system, as well as the core goal- better nutrition, more local food, local awareness of local ercological issues, like pollinator health.   ';
    this.author = 'Greg';
});