app.controller('Area2Controller', function () {
    console.log('Area2Controller');
    this.name = 'Area 2';
});